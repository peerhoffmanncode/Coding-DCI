from django.views.generic import TemplateView

from .models import Reminder


class GermanView(TemplateView):
    template_name = "reminders/germany.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["reminders"] = Reminder.objects.all()
        return context
