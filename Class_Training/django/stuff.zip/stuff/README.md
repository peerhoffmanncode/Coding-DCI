In the only form we have for contacts:
- extract the email, name and reason (use variables to store them)

- Form a string or template that you then send using the Mailchimp API to yourself